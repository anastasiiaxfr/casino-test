<?php get_header(); ?>

<main>

	<h1>
		Page Not Found
	</h1>

	<h2>
		The page you are looking for does not exist.
	</h2>

	<p>
		Sorry, we can't find the page you are looking for. It might be an old link or maybe it moved.
	</p>

</main>

<?php get_footer(); ?>
