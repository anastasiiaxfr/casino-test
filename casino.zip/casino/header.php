<!DOCTYPE html>
<html dir="ltr" lang="en-US">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <?php wp_head(); ?>
    <meta name="description" content="" />

    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, maximum-scale=1"
    />

    <meta name="generator" content="Hugo 0.82.0" />

    <link rel="canonical" href="<?php echo get_template_directory_uri();?>/" />

    <meta property="og:title" content="casino online" />
    <meta property="og:description" content="" />

    <meta property="og:image:height" content="..." />
    <meta property="og:image:width" content="..." />
    <meta property="og:image" content="fav/screenshot.jpg" />

    <meta property="fb:app_id" content="..." />
    <meta property="fb:admins" content="" />

    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="casino online" />
    <meta property="og:url" content="/" />

    <meta name="twitter:title" content="casino online" />
    <meta name="twitter:url" content="/" />
    <meta name="twitter:image" content="fav/screenshot.jpg" />
    <meta name="twitter:card" content="" />

    <meta name="twitter:card" content="..." />

    <meta name="twitter:site" content="/" />
    <meta name="twitter:creator" content="" />

    <meta name="twitter:title" content="casino online" />
    <meta name="twitter:description" content="" />
    <meta name="twitter:image:src" content="..." />

    <meta itemprop="name" content="/" />
    <meta itemprop="description" content="" />
    <meta itemprop="image" content="..." />

    <link href="fav/minilogo.ico" rel="shortcut icon" type="image/x-icon" />
    <link href="fav/minilogo.ico" rel="icon" type="image/x-icon" />

    <link
      rel="shortcut icon"
      href="<?php echo get_template_directory_uri();?>/fav/favicon.png"
      type="image/x-icon"
    />
    <link
      rel="icon"
      href="<?php echo get_template_directory_uri();?>/fav/favicon.png"
      type="image/x-icon"
    />

    <link
      rel="apple-touch-icon"
      sizes="144x144"
      href="<?php echo get_template_directory_uri();?>/fav/apple-touch-icon.png"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="32x32"
      href="<?php echo get_template_directory_uri();?>/fav/favicon-32x32.png"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="<?php echo get_template_directory_uri();?>/fav/favicon-16x16.png"
    />
    <link
      rel="mask-icon"
      href="<?php echo get_template_directory_uri();?>/fav/safari-pinned-tab.svg"
      color="#fff"
    />

    <link
      rel="manifest"
      href="<?php echo get_template_directory_uri();?>/fav/site.webmanifest"
    />
    <link
      rel="mask-icon"
      href="<?php echo get_template_directory_uri();?>/fav/safari-pinned-tab.svg"
      color="#3a1b70"
    />
    <meta name="msapplication-TileColor" content="#3a1b70" />
    <meta name="theme-color" content="#3a1b70" />

    <!-- mobile responsive meta -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, maximum-scale=1"
    />

    <!-- Main Stylesheet -->

    <link
      rel="stylesheet"
      href="<?php echo get_template_directory_uri();?>/scss/main.min.css?v=10-01-2022-1042-91-16"
      media="screen"
    />
    <!-- plugins -->

    <!-- Custom Stylesheet -->

    <link
      rel="stylesheet"
      href="<?php echo get_template_directory_uri();?>/scss/custom.min.css?v=10-01-2022-1042-91-16"
      media="screen"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
      integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>

  <body <?php body_class(); ?>
    class="page__body">

    <main class="page__wrapper">
      <div class="preloader">
        <div class="preloader-dots">
          <div class="dot"></div>
          <div class="dot"></div>
          <div class="dot"></div>
          <div class="dot"></div>
        </div>
      </div>

      <script>
        var preloader = document.querySelector(".preloader");
        setTimeout(() => {
          preloader.style.display = "none";
        }, 600);
      </script>
      <div class="header-span"></div>

      <header class="header">
        <div class="container">
          <div class="d-flex align-items-center justify-content-between">
            <nav class="navbar navbar-expand-lg">
              <div class="container px-0">
                <a
                  class="logo"
                  href="<?php echo get_bloginfo('url') ?>"
                >
                  <img
                    src="<?php echo get_template_directory_uri();?>/images/logo.svg "
                    alt=""
                    width="197"
                    height="71"
                  />
                </a>

                <button
                  class="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <svg class="icon" width="20" height="20">
                    <use xlink:href="#menu"></use>
                  </svg>
                </button>

                <div
                  class="collapse navbar-collapse"
                  id="navbarSupportedContent"
                >


				<?php wp_nav_menu( array( 
    			'theme_location' => 'header-menu', 
    			'container_class' => 'navbar-nav mx-auto mb-2 mb-lg-0' ) ); 
			?>

                  <!-- <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Online casinos in Belarus
                      </a>

                      <ul class="dropdown-menu">
                        <li>
                          <a
                            class="dropdown-item"
                            href="<?php echo get_template_directory_uri();?>/Online%20casinos%20in%20Belarus%201"
                            >Online casinos in Belarus 1</a
                          >
                        </li>

                        <li>
                          <a
                            class="dropdown-item"
                            href="<?php echo get_template_directory_uri();?>/Online%20casinos%20in%20Belarus%202"
                            >Online casinos in Belarus 2</a
                          >
                        </li>
                      </ul>
                    </li>

                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Slots
                      </a>

                      <ul class="dropdown-menu">
                        <li>
                          <a
                            class="dropdown-item"
                            href="<?php echo get_template_directory_uri();?>/casinos1"
                            >Slots1</a
                          >
                        </li>

                        <li>
                          <a
                            class="dropdown-item"
                            href="<?php echo get_template_directory_uri();?>/casinos2"
                            >Slots2</a
                          >
                        </li>
                      </ul>
                    </li>

                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        All games
                      </a>

                      <ul class="dropdown-menu">
                        <li>
                          <a
                            class="dropdown-item"
                            href="<?php echo get_template_directory_uri();?>/casinos"
                            >All casinos2</a
                          >
                        </li>
                      </ul>
                    </li>

                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Bonus
                      </a>

                      <ul class="dropdown-menu">
                        <li>
                          <a
                            class="dropdown-item"
                            href="<?php echo get_template_directory_uri();?>/casinos"
                            >All casinos1</a
                          >
                        </li>
                      </ul>
                    </li>

                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Payment methods
                      </a>

                      <ul class="dropdown-menu">
                        <li>
                          <a
                            class="dropdown-item"
                            href="<?php echo get_template_directory_uri();?>/casinos"
                            >All casinos</a
                          >
                        </li>
                      </ul>
                    </li>
                  </ul> -->
                </div>
              </div>
            </nav>
          </div>
        </div>
      </header>
    
  
