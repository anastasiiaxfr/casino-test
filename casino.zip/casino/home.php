<?php /* Template Name: Home */ ?>
<?php get_header();?>


<div class="page__wrap">

<section class="hero pt-2 pb-lg-5 mb-lg-5"
    style="background-image: url(<?php echo get_template_directory_uri();?>/images/coin1.png)">
    <div class="container">

      <nav class="breadcrumbs mb-5">
        <a href="#" class="breadcrumbs__item">Online Casino <svg class="icon" width="15" height="15">
            <use xlink:href="#arr-rt"></use>
          </svg></a>
        <a href="#" class="breadcrumbs__item breadcrumbs__item--current">Unibet Casino</a>
      </nav>


      <?php 
      $ID =  get_field('casino_review_id');
      $args = array('post_type' =>'casino', 'post_status' => 'publish', 'p' => $ID );
$query = new WP_Query( $args ); if ( $query->have_posts() ) { while ($query->have_posts() ) { $query->the_post(); ?>

      <div class="casino__parent">
        <h1>
          <?php the_title(); ?>
        </h1>
        <div class="row">
          <div class="casino__rating mt-lg-5 col-sm-6">
            <b>
              5.0
            </b>

            <span class="rating">
              <svg class="icon" width="15" height="15">
                <use xlink:href="#star-2"></use>
              </svg>
              <svg class="icon" width="15" height="15">
                <use xlink:href="#star-2"></use>
              </svg>
              <svg class="icon" width="15" height="15">
                <use xlink:href="#star-2"></use>
              </svg>
              <svg class="icon" width="15" height="15">
                <use xlink:href="#star-0"></use>
              </svg>
              <svg class="icon" width="15" height="15">
                <use xlink:href="#star-0"></use>
              </svg>
            </span>
            <span> (16 gamblers voted)</span>
          </div>
          <div class="casino__date col-sm-6 col-lg-12">
            Updated: 2021-11-10
          </div>
        </div>
      </div>

      <div class="casino__excerpt my-5">
        <?php the_content(); ?>
      </div>

      <div class="casino">
        <div class="row mx-0">
          <div class="col-lg-4 col-md-6 casino__info-wrap">
            <div class="row">
              <b class="casino__title col-6 col-lg-12">
                <?php the_title();?>
              </b>

              <div class="casino__rating col-6 col-lg-12">
                <b>5.0</b>
                <div class="rating">
                  <svg class="icon" width="15" height="15">
                    <use xlink:href="#star-2"></use>
                  </svg>
                  <svg class="icon" width="15" height="15">
                    <use xlink:href="#star-2"></use>
                  </svg>
                  <svg class="icon" width="15" height="15">
                    <use xlink:href="#star-2"></use>
                  </svg>
                  <svg class="icon" width="15" height="15">
                    <use xlink:href="#star-2"></use>
                  </svg>
                  <svg class="icon" width="15" height="15">
                    <use xlink:href="#star-2"></use>
                  </svg>
                </div>
              </div>
            </div>

            <div class="casino__info">
              <?php $image = get_field('logo'); ?>
              <img class="casino__logo" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />




              <?php if( have_rows('casino_info') ): ?>
              <?php while( have_rows('casino_info') ): the_row();?>

              <div class="my-2">
                <?php $casino_item = get_sub_field('casino_item'); ?>
                <?php echo $casino_item['casino_item_title'] ; ?>
                <b>
                  <?php echo $casino_item['casino_item_val'] ; ?>
                </b>
              </div>


              <?php endwhile; ?>

              <?php endif; ?>

              <div class="mb-4 mb-md-0">
                <a href="#" class="btn btn--bg">
                  PLAY now
                </a>

                <div class="d-block d-sm-none">
                  <span class="casino__details-toggle">
                    Show more
                    <svg class="icon" width="15" height="15">
                      <use xlink:href="#arr-down"></use>
                    </svg>
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-8 col-md-6 casino__details-wrap">
            <table class="casino__details">
              <tr>
                <td class="">
                  <span class="casino__details-title">Bonus:</span>
                  <b>
                    <?php the_field('bonus_info'); ?>
                  </b>
                </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2">
                  <span class="casino__details-title">
                    Features of the casino
                  </span>
                </td>
              </tr>
              <tr>
                <td>
                  <ul class="casino__feature">
                    <li>


                      <?php if( have_rows('feature_plus') ): ?>
                      <?php while( have_rows('feature_plus') ): the_row(); ?>
                    <li>
                      <svg class="icon me-2" width="15" height="15">
                        <use xlink:href="#i1"></use>
                      </svg>
                      <?php the_sub_field('feature_plus_item'); ?>
                    </li>
                    <?php endwhile; ?>
                    <?php endif; ?>

                    </li>
                    <li>
                      <?php if( have_rows('feature_minus') ): ?>
                      <?php while( have_rows('feature_minus') ): the_row(); ?>
                    <li>
                      <svg class="icon me-2" width="15" height="15">
                        <use xlink:href="#i2"></use>
                      </svg>

                      <?php the_sub_field('feature_minus_item'); ?>
                    </li>
                    <?php endwhile; ?>
                    <?php endif; ?>


                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>
                  <span class="casino__details-title">
                    Available Games
                  </span>
                </td>
              </tr>
              <tr>
                <td>
                  <ul class="casino__games">


                    <?php if( have_rows('games') ): ?>
                    <?php while( have_rows('games') ): the_row(); ?>
                    <li>
                      <svg width="10" height="10" class="icon me-2">
                        <use xlink:href="#check"></use>
                      </svg>
                      <?php the_sub_field('game_title'); ?>
                    </li>
                    <?php endwhile; ?>
                    <?php endif; ?>




                  </ul>
                </td>
              </tr>
              <tr>
                <td>
                  <span class="casino__details-title">
                    Banking methods
                  </span>
                </td>
              </tr>
              <tr>
                <td>
                  <div class="casino__pm">
                    <ul class="pm">



                      <?php if( have_rows('banking_methods') ): ?>
                      <?php while( have_rows('banking_methods') ): the_row(); 
        $image = get_sub_field('pm_image');
        ?>
                      <li>
                        <img src="<?php echo $image['url']; ?>" alt="" />
                      </li>
                      <?php endwhile; ?>
                      <?php endif; ?>



                    </ul>
                  </div>
                </td>
              </tr>
            </table>

            <div class="d-block d-sm-none">
              <span class="casino__details-toggle">
                Show less
                <svg class="icon" width="15" height="15">
                  <use xlink:href="#arr-top"></use>
                </svg>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php } } wp_reset_postdata(); ?>
    <img class="hero__bg" src="<?php echo get_template_directory_uri();?>/images/hero.svg" alt="casino online" />
  </section>


  <div class="bg--1">


    <div class="pt-lg-5 mt-lg-5">





      <section class="section pt-5">
        <div class="container">
          <div class="row">
            <div class="col-lg-8 content">

              <?php the_content() ;?>


            </div>
            <aside class="col-lg-4">
              <nav class="toc">

                <?php if( have_rows('toc') ): ?>

                <?php while( have_rows('toc') ): the_row(); 
        ?>
                <a href="<?php the_sub_field('toc_link'); ?>">
                  <?php the_sub_field('toc_title'); ?>
                </a>
                <?php endwhile; ?>

                <?php endif; ?>



              </nav>
            </aside>
          </div>
        </div>
      </section>


    </div>




    <div class="pb-5">





      <section class="section py-5">
        <div class="container">
          <div class="row">
            <div class="col-md-8 mx-auto text-center">
              <h2>FAQ</h2>





              <div class="accordion mt-5">


                <div>
                  <?php $args = array('post_type' =>'faq', 'post_status' => 'publish' );
$query = new WP_Query( $args ); if ( $query->have_posts() ) { while ($query->have_posts() ) { $query->the_post(); ?>


                  <div class="accordion-item">
                    <h2 class="accordion-header" id="heading-test0-<?php echo get_the_id();?>">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapse-test0-<?php echo get_the_id();?>" aria-expanded="true"
                        aria-controls="collapse-test0-<?php echo get_the_id();?>">
                        <?php echo the_title(); ?>
                      </button>
                    </h2>
                    <div id="collapse-test0-<?php echo get_the_id();?>" class="accordion-collapse collapse"
                      aria-labelledby="heading-test0-<?php echo get_the_id();?>" data-bs-parent="#accordionExample">
                      <div class="accordion-body">
                        <?php echo the_content();?>
                      </div>
                    </div>
                  </div>

                  <?php } } wp_reset_postdata(); ?>
                </div>






              </div>

            </div>
          </div>
        </div>
      </section>


    </div>


  </div>

</div>



<?php get_footer(); ?>