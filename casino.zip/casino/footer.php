</main>

<footer class="footer">
	<div class="footer__bg">
		<img src="<?php echo get_template_directory_uri();?>/images/footer.svg" alt="ALT">
	</div>

	<div class="container">
		<hr class="divider">
		<div class="d-flex align-items-center justify-content-between flex-wrap">


			<a class="logo" href="<?php echo get_bloginfo('url') ?>">


				<img src="<?php echo get_template_directory_uri();?>/images/logo.svg " alt="" width="197" height="71">



			</a>
			
			<?php wp_nav_menu( array( 
    			'theme_location' => 'footer-menu', 
    			'container_class' => 'footer__nav order-1' ) ); 
			?>
			<!-- <ul class="footer__nav order-1">


				<li>
					<a href="#">
						Cookie Policy
					</a>
				</li>




				<li>
					<a href="#">
						Privacy Policy
					</a>
				</li>




				<li>
					<a href="#">
						Terms &amp; Conditions
					</a>
				</li>




				<li>
					<a href="#">
						Sitemap
					</a>
				</li>



			</ul> -->

			<nav class="soc my-4 order-lg-1">

				<a href="#" title="facebook"><i class="fa-brands fa-facebook-f"></i></i></a>

				<a href="#" title="youtube"><i class="fa-brands fa-youtube"></i></i></a>

				<a href="#" title="twitter"><i class="fa-brands fa-twitter"></i></i></a>

				<a href="#" title="telegram"><i class="fa-brands fa-telegram"></i></i></a>

			</nav>



		</div>
	</div>
</footer>



<script src="<?php echo get_template_directory_uri();?>/plugins/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo get_template_directory_uri();?>/plugins/js/jquery.min.js"></script>



<script src="<?php echo get_template_directory_uri();?>/js/script.min.js?v=%2010-01-2022-1042-91-16"></script><svg
	width="0" height="0" class="hidden">
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 21" id="star-0">
		<path
			d="M11.6139 0.880859L11.6139 0.880852C11.3628 0.372844 10.6367 0.37332 10.3862 0.880656L10.3861 0.88086L7.90474 5.89922C7.65912 6.39605 7.1845 6.73982 6.63607 6.81924L1.08751 7.62402L1.08733 7.62405C0.524978 7.7054 0.302602 8.39317 0.707713 8.7876C0.70774 8.78763 0.707767 8.78766 0.707794 8.78768L4.7227 12.6939L4.72279 12.694C5.11963 13.0803 5.30143 13.6376 5.20729 14.1838M11.6139 0.880859L4.71455 14.0989M11.6139 0.880859L14.0952 5.89922M11.6139 0.880859L14.0952 5.89922M5.20729 14.1838L4.71455 14.0989M5.20729 14.1838L5.20733 14.1835L4.71455 14.0989M5.20729 14.1838L4.25969 19.6994L4.25967 19.6995C4.16413 20.255 4.74946 20.6834 5.25363 20.4188L5.25365 20.4188L10.2163 17.8148L10.2163 17.8148C10.7069 17.5574 11.2931 17.5574 11.7837 17.8148L11.7837 17.8148L16.7461 20.4187M4.71455 14.0989L3.76691 19.6147C3.60077 20.5807 4.61679 21.3177 5.48598 20.8615L10.4486 18.2575C10.7937 18.0765 11.2063 18.0765 11.5514 18.2575L16.514 20.8615M16.7461 20.4187L16.514 20.8615M16.7461 20.4187C17.2508 20.6833 17.8358 20.2546 17.7403 19.6995L17.7403 19.6994L16.7926 14.1837M16.7461 20.4187L16.7463 20.4188L16.514 20.8615M16.514 20.8615C17.3832 21.3172 18.3992 20.5807 18.233 19.6147M17.2854 14.0989L18.233 19.6147M17.2854 14.0989C17.2194 13.7155 17.347 13.3239 17.6259 13.0522L18.233 19.6147M17.2854 14.0989L16.7926 14.1837M17.2854 14.0989L16.7926 14.1835C16.6987 13.6374 16.8804 13.0803 17.2771 12.694L17.2772 12.6939L21.2923 8.7876L21.2923 8.78757C21.697 8.39388 21.4755 7.70573 20.9124 7.62401M18.233 19.6147L16.7926 14.1837M16.7926 14.1837L15.4355 6.3244M20.9124 7.62401L20.9125 7.62402L20.9842 7.1292L20.9124 7.62401ZM20.9124 7.62401L15.3639 6.81924M15.3639 6.81924L15.4355 6.3244M15.3639 6.81924C14.8155 6.73982 14.3408 6.39605 14.0952 5.89922M15.3639 6.81924L15.3638 6.81922L15.4355 6.3244M15.4355 6.3244L14.0952 5.89922"
			stroke="#FF9721"></path>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 21" id="star-1">
		<mask id="mask0_123_276" maskUnits="userSpaceOnUse" x="0" y="0" width="22" height="21">
			<path
				d="M12.0621 0.659246L14.5434 5.67763C14.716 6.02667 15.0496 6.26851 15.4355 6.3244L20.9842 7.1292C21.9563 7.27027 22.344 8.46211 21.641 9.14598L17.6259 13.0522C17.347 13.3239 17.2194 13.7155 17.2854 14.0989L18.233 19.6147C18.3992 20.5807 17.3832 21.3172 16.514 20.8615L11.5514 18.2575C11.2063 18.0765 10.7937 18.0765 10.4486 18.2575L5.48598 20.8615C4.61679 21.3177 3.60077 20.5807 3.76691 19.6147L4.71455 14.0989C4.78063 13.7155 4.65306 13.3239 4.37403 13.0522L0.359046 9.14598C-0.344002 8.46166 0.0437752 7.26981 1.01574 7.1292L6.56441 6.3244C6.95035 6.26851 7.28397 6.02667 7.45652 5.67763L9.93785 0.659246C10.372 -0.219749 11.6275 -0.219749 12.0621 0.659246Z"
				fill="#FF9721"></path>
		</mask>
		<g mask="url(#mask0_123_276)">
			<rect x="-1" width="12" height="21" fill="#FF9721"></rect>
		</g>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 21" id="star-2">
		<path
			d="M12.0621 0.659246L14.5434 5.67763C14.716 6.02667 15.0496 6.26851 15.4355 6.3244L20.9842 7.1292C21.9563 7.27027 22.344 8.46211 21.641 9.14598L17.6259 13.0522C17.347 13.3239 17.2194 13.7155 17.2854 14.0989L18.233 19.6147C18.3992 20.5807 17.3832 21.3172 16.514 20.8615L11.5514 18.2575C11.2063 18.0765 10.7937 18.0765 10.4486 18.2575L5.48598 20.8615C4.61679 21.3177 3.60077 20.5807 3.76691 19.6147L4.71455 14.0989C4.78063 13.7155 4.65306 13.3239 4.37403 13.0522L0.359046 9.14598C-0.344002 8.46166 0.0437752 7.26981 1.01574 7.1292L6.56441 6.3244C6.95035 6.26851 7.28397 6.02667 7.45652 5.67763L9.93785 0.659246C10.372 -0.219749 11.6275 -0.219749 12.0621 0.659246Z"
			fill="#FF9721"></path>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 14" id="arr-down">
		<path d="M3.4 4.5L6.9 8L10.4 4.5L11.8 5.2L6.9 10.1L2 5.2L3.4 4.5Z" fill="white"></path>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4 19" id="arr-rt">
		<g clip-path="url(#clip0_1_808)">
			<path d="M0 12.5L2.5 10L0 7.5L0.5 6.5L4 10L0.5 13.5L0 12.5Z" fill="#D2D7E1"></path>
		</g>
		<defs>
			<clipPath id="clip0_1_808">
				<rect width="4" height="19" fill="white"></rect>
			</clipPath>
		</defs>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 14" id="arr-top">
		<path d="M3.4 10.1001L6.9 6.6001L10.4 10.1001L11.8 9.4001L6.9 4.5001L2 9.4001L3.4 10.1001Z" fill="white"></path>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 7" id="check">
		<path d="M1 3.04545L3.97143 6L9 1" stroke="white" stroke-width="2" stroke-linecap="round"
			stroke-linejoin="round"></path>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" id="close">
		<path
			d="M15.0965 14L21.5443 7.55218C21.6717 7.40339 21.7383 7.21199 21.7308 7.01625C21.7232 6.8205 21.642 6.63481 21.5035 6.49629C21.365 6.35778 21.1793 6.27663 20.9836 6.26907C20.7878 6.26151 20.5964 6.32809 20.4476 6.45551L13.9999 12.9033L7.55209 6.44773C7.40563 6.30127 7.20699 6.21899 6.99987 6.21899C6.79275 6.21899 6.59411 6.30127 6.44765 6.44773C6.30119 6.59419 6.21891 6.79283 6.21891 6.99995C6.21891 7.20708 6.30119 7.40572 6.44765 7.55218L12.9032 14L6.44765 20.4477C6.36623 20.5175 6.3001 20.6033 6.25342 20.6998C6.20673 20.7962 6.1805 20.9014 6.17636 21.0085C6.17222 21.1156 6.19027 21.2224 6.22937 21.3222C6.26848 21.422 6.32779 21.5127 6.40359 21.5885C6.47939 21.6643 6.57003 21.7236 6.66984 21.7627C6.76965 21.8018 6.87646 21.8198 6.98358 21.8157C7.09069 21.8115 7.1958 21.7853 7.29229 21.7386C7.38879 21.6919 7.47459 21.6258 7.54431 21.5444L13.9999 15.0966L20.4476 21.5444C20.5964 21.6718 20.7878 21.7384 20.9836 21.7308C21.1793 21.7233 21.365 21.6421 21.5035 21.5036C21.642 21.3651 21.7232 21.1794 21.7308 20.9837C21.7383 20.7879 21.6717 20.5965 21.5443 20.4477L15.0965 14Z"
			fill="white"></path>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" id="i1">
		<rect width="18" height="18" rx="3" fill="url(#paint0_linear_1_1064)"></rect>
		<rect x="8" y="4" width="2" height="10" rx="1" fill="white"></rect>
		<rect x="4" y="10" width="2" height="10" rx="1" transform="rotate(-90 4 10)" fill="white"></rect>
		<defs>
			<linearGradient id="paint0_linear_1_1064" x1="14.85" y1="15.75" x2="3.6" y2="2.025"
				gradientUnits="userSpaceOnUse">
				<stop stop-color="#F07300"></stop>
				<stop offset="1" stop-color="#FFB017"></stop>
			</linearGradient>
		</defs>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" id="i2">
		<rect width="18" height="18" rx="3" fill="url(#paint0_linear_1_1071)"></rect>
		<rect x="4" y="10" width="2" height="10" rx="1" transform="rotate(-90 4 10)" fill="white"></rect>
		<defs>
			<linearGradient id="paint0_linear_1_1071" x1="14.85" y1="15.75" x2="3.6" y2="2.025"
				gradientUnits="userSpaceOnUse">
				<stop stop-color="#0076B8"></stop>
				<stop offset="1" stop-color="#11A9FE"></stop>
			</linearGradient>
		</defs>
	</symbol>
	<symbol fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 8" id="menu">
		<line x1="8" y1="6" x2="17" y2="6" stroke="white" stroke-width="2" stroke-linecap="round"></line>
		<line x1="1" y1="1" x2="17" y2="1" stroke="white" stroke-width="2" stroke-linecap="round"></line>
	</symbol>
</svg>
<script>
	var casino_toggle = document.querySelectorAll('.casino__details-toggle');
	var casino_detail = document.querySelector('.casino__details-wrap')

	for (var i = 0; i < casino_toggle.length; i++) {
		casino_toggle[i].addEventListener('click', function () {
			casino_toggle[0].classList.toggle('d-none');
			casino_detail.classList.toggle('d-block');
			this.classList.toggle('d-block');
		});
	}

</script>

<?php wp_footer(); ?>

</body>

</html>